package com.slk.training.customerapp;

import java.time.LocalDate;
//Plain Old Java Class (POJO class)
//Java Class which is a blue print of real world object customer
public class Customer {

    //Properties or fields or data member
    private int id; //primitive data type
    private String firstName; //String type
    private String lastName;
    private String email;
    private LocalDate dateOfBirth;
    //No arg constructor
    public Customer() {
    }

    //All arg or Parameterized constructor
    public Customer(int id, String firstName, String lastName, String email, LocalDate dateOfBirth) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }

    public Customer(int id, String email, LocalDate dateOfBirth) {
        this.id = id;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }

    //accessor methods or getter/setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    //String representation of an object. This method is provided in java.lang.Object class
    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                '}';
    }
}
