package com.slk.training.customerapp;

import java.time.LocalDate;
import java.util.Arrays;

public class ArraysOfCustomersTest {
    public static void main(String[] args) {
        Customer customer = new Customer();
        customer.setFirstName("Jane");
        customer.setLastName("Doe");
        customer.setEmail("jane@doe");
        customer.setDateOfBirth(LocalDate.of(1980, 1, 1));
        customer.setId(1);
        Customer customer1 = new Customer(2,"Rahul","Raj","rahul@raj.com",LocalDate.of(1986, 11, 10));
        Customer customer2 = new Customer(3,"Rohit","Raman","rohit@raman.com",LocalDate.of(1982, 5, 20));

        Customer[] customers = new Customer[3];
        customers[0] = customer;
        customers[1] = customer1;
        customers[2] = customer2;
        System.out.println(customers);
        for(Customer c : customers){
            System.out.println(c);
        }
        System.out.println("*******************************************");
        int[] arrayOfInts = new int[5];
        arrayOfInts[0]=10;
        arrayOfInts[1]=2;
        arrayOfInts[2]=6;
        arrayOfInts[3]=4;
        arrayOfInts[4]=1;
        System.out.println(Arrays.toString(arrayOfInts));
        Arrays.sort(arrayOfInts);
        System.out.println(Arrays.toString(arrayOfInts));
        int[] arrOfInt= Arrays.copyOf(arrayOfInts,5);
        System.out.println(Arrays.toString(arrOfInt));

    }
}
