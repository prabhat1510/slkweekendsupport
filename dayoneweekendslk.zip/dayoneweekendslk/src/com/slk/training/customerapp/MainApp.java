package com.slk.training.customerapp;

import java.time.LocalDate;

public class MainApp {
    public static void main(String[] args) {
        //customer is an object reference
        //invoking Customer() constructor using new keyword
        Customer customer = new Customer();
        System.out.println(customer);
        //Setting object properties with values
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setId(1);
        customer.setDateOfBirth(LocalDate.of(1980, 1, 1));
        System.out.println(customer.getFirstName());
        System.out.println(customer.getLastName());
        System.out.println(customer.getId());
        System.out.println(customer.getDateOfBirth());
        System.out.println(customer);
        Customer customer2 = new Customer(2,"Jack","Maa","jack@maa.com",LocalDate.of(1989, 10, 11));
        System.out.println(customer2);
        System.out.println(customer2.getDateOfBirth());
    }
}
