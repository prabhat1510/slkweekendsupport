package com.slk.training.customerapp;

public class DataTypesAndVariableTest {
    public static void main(String[] args) {
        /**
         * int  =0      Integer
         * byte         Byte
         * short        Short
         * float = 15.5f  Float
         * double =15.50  Double
         * char ='c'  Character
         * boolean =false Boolean
         * long =2l  Long
         */
        int num=15;
        Integer num2=num;
        System.out.println(num);
        System.out.println(num2);
        int y= num2;
        System.out.println(y);
        //Primitive array
        //Primitive array is used when we know size or count of elements to be stored in an array
        int[] arrayOfNumbers = new int[5];
        arrayOfNumbers[0]=1;
        arrayOfNumbers[1]=2;
        arrayOfNumbers[2]=3;
        arrayOfNumbers[3]=4;
        arrayOfNumbers[4]=5;
        //arrayOfNumbers[5]=6;//Error
        System.out.println(arrayOfNumbers[0]);
        System.out.println("**************************");
        for(int i=0;i<arrayOfNumbers.length;i++){
            System.out.println(arrayOfNumbers[i]);
        }
        char[] arrayOfCharacters = new char[10];
        arrayOfCharacters[0]='a';
        arrayOfCharacters[1]='b';
        arrayOfCharacters[2]='c';
        arrayOfCharacters[3]='d';
        arrayOfCharacters[4]='e';
        arrayOfCharacters[5]='f';
        arrayOfCharacters[6]='g';
        arrayOfCharacters[7]='h';
        arrayOfCharacters[8]='i';
        arrayOfCharacters[9]='j';
        System.out.println(arrayOfCharacters);
        String[] arrayOfStrings = new String[5];
        arrayOfStrings[0]="Good";
        arrayOfStrings[1]="Morning";
        arrayOfStrings[2]="Hope";
        arrayOfStrings[3]="I am ";
        arrayOfStrings[4]="giving you all good vibes";
        System.out.println(arrayOfStrings);
        for(String s: arrayOfStrings){
            System.out.println(s);
        }



    }
}
