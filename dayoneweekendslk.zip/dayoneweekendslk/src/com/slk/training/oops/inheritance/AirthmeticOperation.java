package com.slk.training.oops.inheritance;

public class AirthmeticOperation extends Addition implements Calculator,Multiplication {
    @Override
    public double calculate(double num1, double num2) {
        return num1 - num2;
    }

    @Override
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }
}
