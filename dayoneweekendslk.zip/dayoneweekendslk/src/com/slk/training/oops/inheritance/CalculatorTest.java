package com.slk.training.oops.inheritance;

public class CalculatorTest {
    public static void main(String[] args) {
        AirthmeticOperation operation = new AirthmeticOperation();
        System.out.println(operation.calculate(15,10));
        System.out.println(operation.add(15,10));
        System.out.println(operation.multiply(15,10));
    }
}
