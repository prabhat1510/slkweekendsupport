package com.slk.training.oops.inheritance;

import java.util.List;
//Manager class is inherting Employee class
//Derived class or Child class or Sub class
public class Manager extends Employee{
    //Properties projects which is more than one
    //Here List<String> is used store the name of the projects
    private List<String> projects;

    public List<String> getProjects() {
        return projects;
    }

    public void setProjects(List<String> projects) {
        this.projects = projects;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "projects=" + projects +
                '}';
    }
}
