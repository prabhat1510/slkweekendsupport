package com.slk.training.oops.inheritance;

import java.sql.SQLOutput;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        Manager manager = new Manager();
        manager.setFirstName("John");
        manager.setLastName("Doe");
        manager.setEmpId(1);
        manager.setEmail("john@gmail.com");
        manager.setDateOfBirth(LocalDate.of(1975,10,10));
        manager.setSalary(500.0);
        List<String> projects = new ArrayList<String>();
        projects.add("Project1");
        projects.add("Project2");
        manager.setProjects(projects);
        System.out.println(manager);
        System.out.println(manager.getEmpId());
        System.out.println(manager.getEmail());

    }
}
