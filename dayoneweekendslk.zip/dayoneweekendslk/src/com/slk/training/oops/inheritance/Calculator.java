package com.slk.training.oops.inheritance;
//
public interface Calculator {
   //abstract method
    public double calculate(double num1, double num2);
}
