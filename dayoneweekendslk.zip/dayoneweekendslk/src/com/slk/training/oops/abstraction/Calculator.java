package com.slk.training.oops.abstraction;

//We cannot create an object of an abstract class
public abstract class Calculator {
    //one abstract method is must
    public abstract double calculate(double num1, double num2);
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }
}
