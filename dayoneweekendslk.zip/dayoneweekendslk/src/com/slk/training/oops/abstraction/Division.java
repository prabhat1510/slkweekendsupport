package com.slk.training.oops.abstraction;

public interface Division {

    //Abstract methods
    public double division(double num1, double num2);
    public void displayResult();
}
