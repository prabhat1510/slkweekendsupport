package com.slk.training.oops.abstraction;

public class Test {
    public static void main(String[] args) {
        ArithmeticOps arithmeticOps = new ArithmeticOps();
        arithmeticOps.displayResult();
        System.out.println(arithmeticOps.calculate(15,10));
        System.out.println(arithmeticOps.multiply(15,10));
        System.out.println(arithmeticOps.division(15,10));
    }
}
