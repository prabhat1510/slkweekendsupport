package com.slk.training.oops.polymorphism.methodoverloading;

public class Addition {
    //Method Overloading
    public int add(int num1, int num2) {
        return num1 + num2;
    }

    public double add(double num1, double num2) {
        return num1 + num2;
    }

    public float add(float num1, float num2) {
        return num1 + num2;
    }

    public int add(int num1, int num2,int num3) {
        return num1 + num2+num3;
    }
}
