package com.slk.training.oops.polymorphism.methodoverriding;

public class AddOps extends Calculate {
    @Override
    public int calculate(int num1, int num2) {
        return num1 + num2;
    }
    /**
    public void display(){
        System.out.println("Its a final display method of calculate class");
    }*/

}
