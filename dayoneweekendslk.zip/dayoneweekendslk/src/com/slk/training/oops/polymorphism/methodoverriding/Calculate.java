package com.slk.training.oops.polymorphism.methodoverriding;

public class Calculate {
    public int calculate(int num1, int num2) {
        return num1 + num2;
    }
    public final void display(){
        System.out.println("Its a final display method of calculate class");
    }
}
