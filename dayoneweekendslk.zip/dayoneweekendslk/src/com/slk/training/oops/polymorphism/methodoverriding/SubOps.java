package com.slk.training.oops.polymorphism.methodoverriding;

public class SubOps extends Calculate {
    @Override
    public int calculate(int num1, int num2) {
        return num1 - num2;
    }
}
