package com.slk.training.oops.polymorphism.methodoverriding;

public class MulOps  extends Calculate{
    @Override
    public int calculate(int num1, int num2){
        return num1*num2;
    }
}
