package com.slk.training.oops.polymorphism.methodoverriding;

public class Test {
    public static void main(String[] args) {
        AddOps ops = new AddOps();
        System.out.println(ops.calculate(15,10));
        MulOps ops2 = new MulOps();
        System.out.println(ops2.calculate(15,10));
        SubOps ops3 = new SubOps();
        System.out.println(ops3.calculate(15,10));
    }
}
