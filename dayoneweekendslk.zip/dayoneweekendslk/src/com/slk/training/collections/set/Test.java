package com.slk.training.collections.set;

import com.slk.training.collections.lists.Student;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.setStudentId(1);
        s1.setFirstName("Amitabh");
        s1.setLastName("Bachhan");
        com.slk.training.collections.lists.Student s2 = new com.slk.training.collections.lists.Student();
        s2.setStudentId(2);
        s2.setFirstName("Abhishek");
        s2.setLastName("Bachhan");
        com.slk.training.collections.lists.Student s3 = new Student();
        s3.setStudentId(3);
        s3.setFirstName("Aishwarya Rai");
        s3.setLastName("Bachhan");

        s3.setStudentId(3);
        s3.setFirstName("Aishwarya Rai");
        s3.setLastName("Bachhan");

        Set<Student> set = new HashSet<Student>();
        set.add(s1);
        set.add(s2);
        set.add(s3);
        set.add(s3);
        System.out.println(set);
        System.out.println("******************************************");
        //TreeSet -- Sorted Collection with no duplicates
        Set<Integer> setOfIntegers = new TreeSet<Integer>();
        setOfIntegers.add(11);
        setOfIntegers.add(10);
        setOfIntegers.add(20);
        setOfIntegers.add(13);
        setOfIntegers.add(20);
        setOfIntegers.add(13);
        System.out.println(setOfIntegers);
        System.out.println("******************************************");
        Set<Student> setOfStudentsUsingTreeSet = new TreeSet<>(Comparator.comparing(Student::getFirstName));
        setOfStudentsUsingTreeSet.add(s2);
        setOfStudentsUsingTreeSet.add(s3);
        setOfStudentsUsingTreeSet.add(s1);
        //setOfStudentsUsingTreeSet.add(s3);
        System.out.println(setOfStudentsUsingTreeSet);

       /* Set<Student> setOfStudents = new TreeSet<>();
        setOfStudents.add(s1);
        setOfStudents.add(s2);
        setOfStudents.add(s3);*/

    }
}
