package com.slk.training.collections.set;

import java.util.Objects;

public class Student {
    private Integer studentId;
    private String firstName;
    private String lastName;
    private Student o;

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public boolean equals(Object o1) {
        if (o1 == null || getClass() != o1.getClass()) return false;
        Student student = (Student) o1;
        return Objects.equals(studentId, student.studentId) && Objects.equals(firstName, student.firstName) && Objects.equals(lastName, student.lastName) && Objects.equals(o, student.o);
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentId, firstName, lastName, o);
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }


}
