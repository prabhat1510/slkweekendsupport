package com.slk.training.collections.set;

import java.time.LocalDate;
import java.util.Objects;

public class StudentNew implements Comparable<StudentNew>{
    private Integer id;
    private String name;
    private LocalDate dateOfBirth;

    public StudentNew() {
    }

    public StudentNew(Integer id, String name, LocalDate dateOfBirth) {
        this.id = id;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }



    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                '}';
    }
    @Override
    public int compareTo(StudentNew o) {

        if (this.getId() == o.getId()) {
            return 0;
        } else {
            return this.getId() > o.getId() ? 1 : -1;
        }
    }
}

