package com.slk.training.collections.set;

import java.time.LocalDate;
import java.util.Set;
import java.util.TreeSet;

public class StudentNewTest {
    public static void main(String[] args) {
        StudentNew stud1 = new StudentNew();
        stud1.setId(11);
        stud1.setName("Aswin");
        stud1.setDateOfBirth(LocalDate.of(2000, 10, 15));
        StudentNew stud2 = new StudentNew(12,"Rajesh", LocalDate.of(2001, 11, 16));
        StudentNew stud3 = new StudentNew(13,"ShakthiVel",LocalDate.of(2000, 9, 11));
        StudentNew stud4 = new StudentNew(14,"Thiru",LocalDate.of(2002, 8, 15));
        StudentNew stud5 = new StudentNew(16,"Rishidhar",LocalDate.of(2000, 6, 10));
        //Two different objects with same values or data
        StudentNew stud6 = new StudentNew(12,"Rajesh",LocalDate.of(2001, 11, 16));
        StudentNew stud7 = new StudentNew(13,"ShakthiVel",LocalDate.of(2000, 9, 11));
        Set<StudentNew> setOfStudents = new TreeSet<StudentNew>();
        setOfStudents.add(stud1);
        setOfStudents.add(stud4);
        setOfStudents.add(stud5);
        setOfStudents.add(stud7);
        setOfStudents.add(stud3);
        setOfStudents.add(stud2);
        setOfStudents.add(stud6);
        System.out.println(setOfStudents);
        System.out.println("***************************************************");
    }
}
