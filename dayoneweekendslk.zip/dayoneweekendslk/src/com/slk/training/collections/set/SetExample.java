package com.slk.training.collections.set;

import java.util.*;

/**
 * •
 * A
 * Set is an unordered Collection that
 * cannot contain duplicate elements.
 */
public class SetExample {
    public static void main(String[] args) {
        //HashSet-- Unordered Collection with no duplicates
        Set<Integer> set = new HashSet<Integer>();
        set.add(11);
        set.add(22);
        set.add(33);
        set.add(34);
        set.add(33);
        System.out.println(set.toString());
        //HashSet --Unordered Collection with no duplicates
       // Set<String> setOfStrings = new HashSet<String>();
        //LinkedHashSet --ordered Collection with no duplicates
        //Set<String> setOfStrings = new LinkedHashSet<String>();
        //TreeSet --- Sorted Collection with no duplicates

        Set<String> setOfStrings = new TreeSet<String>();
        setOfStrings.add("John");
        setOfStrings.add("Jane");
        setOfStrings.add("Jack");
        setOfStrings.add("Jane");
        setOfStrings.add("Julie");
        System.out.println(setOfStrings);
        System.out.println("********Traversing the set elements using iterator*****");
        Iterator<String> it = setOfStrings.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        System.out.println("********Traversing the set elements using for*****");
        for(String s: setOfStrings){
            System.out.println(s);
        }

    }
}
