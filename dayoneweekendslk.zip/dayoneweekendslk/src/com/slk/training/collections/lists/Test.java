package com.slk.training.collections.lists;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<Student>();
        Student s1 = new Student();
        s1.setStudentId(1);
        s1.setFirstName("Amitabh");
        s1.setLastName("Bachhan");
        Student s2 = new Student();
        s2.setStudentId(2);
        s2.setFirstName("Abhishek");
        s2.setLastName("Bachhan");
        Student s3 = new Student();
        s3.setStudentId(3);
        s3.setFirstName("Aishwarya Rai");
        s3.setLastName("Bachhan");
        students.add(s1);
        students.add(s2);
        students.add(s3);
        System.out.println(students);
        for(Student s: students){
            System.out.println(s);
        }

    }
}
