package com.slk.training.collections.lists;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ListExample {

    public static void main(String[] args) {
        List<String> list1 = new ArrayList<String>();
        System.out.println(list1.isEmpty());
        list1.add("John");//index 0
        list1.add("Jack");//index 1
        list1.add("Jill");//index 2
        list1.add("John");//index 3
        list1.add("Jane");//index 4
        list1.add("Julie");//index 5
        System.out.println(list1);
        //getting an element at particular index position
        System.out.println(list1.get(2));
        System.out.println(list1.isEmpty());
        System.out.println(list1.size());
        System.out.println("********using iterator******");
        //Traversing the list using iterator
        Iterator<String> it = list1.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        System.out.println("********using classic for ******");
        for(int i=0;i<list1.size();i++){
            System.out.println(list1.get(i));
        }

        System.out.println("********using advanced for loop ******");
        for(String s: list1){
            System.out.println(s);
        }
        System.out.println("********using for each******");
        list1.forEach(System.out::println); //Introduced in Java 8
        System.out.println("*****************************");
        List<Integer> list2 = new ArrayList<Integer>();
        list2.add(1);
        list2.add(2);
        List<Integer> list3 = Arrays.asList(1, 2, 3, 4, 5);
        list2.add(1,15);
        System.out.println(list2);
    }
}
