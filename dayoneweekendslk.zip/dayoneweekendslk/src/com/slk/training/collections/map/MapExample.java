package com.slk.training.collections.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * A
 * Map is an object which maps keys to values.
 * A map cannot contain duplicate keys and each
 * key can map to at most one value
 */
public class MapExample {
    public static void main(String[] args) {
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"Rajesh");
        map.put(2,"ShakthiVel");
        map.put(3,"ShakthiVel");
        map.put(4,"Raju");
        map.put(4,null);
        map.put(null,"Rakesh");
        map.put(5,null);
        map.put(null,null);
        System.out.println(map);
        //HashMap: Unordered with no duplicate
        Map<Integer,String> map2 = new HashMap<>();
        map2.put(101,"John"); //Adding objects in Map
        map2.put(105,"Jack");
        map2.put(103,"Ben");
        map2.put(104,"Bella");
        map2.put(102,"Ben"); //Adding duplicates values
        //Returns Set of keys
        Set<Integer> setOfKeys = map2.keySet();
        Iterator<Integer> iterator = setOfKeys.iterator();
        while(iterator.hasNext()){
            Integer key = iterator.next();
            String value = map2.get(key);
            System.out.println("key= "+key+" value= "+value);
        }


    }
}
