package com.slk.training;

public class Demo {
    //Entry point of execution of Java Program
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
